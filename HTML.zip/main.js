function openLogin(){
  window.location.href = "login.html";
}

function openAdmin(){
  window.location.href = "admin.html";
}